var fs = require('fs');
var request = require('request');
fs.createReadStream('test2.zip').pipe(request.post('http://localhost:3000/'));